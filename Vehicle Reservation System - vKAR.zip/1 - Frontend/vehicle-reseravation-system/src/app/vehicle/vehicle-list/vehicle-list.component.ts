import { Component, OnInit } from '@angular/core';
import { VehicleService } from 'src/app/service/vehicle.service';
import { Observable } from 'rxjs';
import { Vehicle } from 'src/app/models/vehicle';
import { Router } from '@angular/router';
import { FormBuilder, Validators } from '@angular/forms';
import { UserService } from 'src/app/service/user.service';

@Component({
  selector: 'app-vehicle-list',
  templateUrl: './vehicle-list.component.html',
  styleUrls: ['./vehicle-list.component.css']
})
export class VehicleListComponent implements OnInit {

  isCar : boolean
  isBike : boolean
  isAdd : boolean
  isSUV : boolean
  isSedan : boolean
  isHatchback : boolean
  isScooter : boolean
  isSport : boolean
  isStandard : boolean
  isCruiser : boolean
  isAllCars : boolean
  isAllBikes : boolean
  isAdded : boolean
  cars : Vehicle[]
  bikes : Vehicle[]
  addVehicleForm = this.formBuilder.group({
    vehicleNumber: ['',Validators.required],
    vehicleName: ['',Validators.required],
    category: ['',Validators.required],
    branch: ['',Validators.required],
    subCategory: ['',Validators.required],
    insuranceExpiryDate: ['',Validators.required],
    lastServiceDate: ['',Validators.required],
    serviceDueDate: ['',Validators.required],
    fee: ['',Validators.required]
  })

  constructor(private vehicleService: VehicleService, private router: Router, private formBuilder: FormBuilder, private userService: UserService) { }

  ngOnInit() {
    this.isCar = true;
    this.isBike = false;
    this.isAdd = false;
    this.isAllBikes = true;
    this.isAllCars = true;
    this.vehicleService.getCars().subscribe(
      data => {
        this.cars = data
        console.log(this.cars)
      }
    )
    this.vehicleService.getBikes().subscribe(
      data => {
        this.bikes = data
        console.log(this.bikes)
      }
    )
  }
  getUser(){
    return this.userService.loggedInUser
  }

  isAdmin()
  {
    return this.userService.isAdmin
  }
  carClick()
  {
    this.isCar = true;
    this.isBike = false;
    this.isAdd = false;
  }
  bikeClick()
  {
    this.isBike = true;
    this.isCar = false;
    this.isAdd = false;
  }
  addClick()
  {
    this.isAdd = true;
    this.isCar = false;
    this.isBike = false;
    this.isAdded = false;
    this.addVehicleForm = this.formBuilder.group({
      vehicleNumber: ['',Validators.required],
      vehicleName: ['',Validators.required],
      category: ['',Validators.required],
      branch: ['',Validators.required],
      subCategory: ['',Validators.required],
      insuranceExpiryDate: ['',Validators.required],
      lastServiceDate: ['',Validators.required],
      serviceDueDate: ['',Validators.required],
      fee: ['',Validators.required]
    })
  }
  suvClick()
  {
    this.isSedan = false
    this.isHatchback = false
    this.isAllCars = false
    if(this.isSUV == true)
    {
      this.isSUV = false
      this.isAllCars = true
    }
    else
    {
      this.isSUV = true
    }
  }
  suvCars()
  {
    return this.cars.filter(suv => suv.category == 'Car' && suv.subCategory == 'SUV')
  }
  sedanClick()
  {
    this.isHatchback = false
    this.isSUV = false
    this.isAllCars = false
    if(this.isSedan == true)
    {
      this.isSedan = false
      this.isAllCars = true
    }
    else
    {
      this.isSedan = true
    }
  }
  sedanCars()
  {
    return this.cars.filter(sedan => sedan.category == 'Car' && sedan.subCategory == 'Sedan')
  }
  hatchbackClick()
  {
    this.isSUV = false
    this.isSedan = false
    this.isAllCars = false
    if(this.isHatchback == true)
    {
      this.isHatchback = false
      this.isAllCars = true
    }
    else
    {
      this.isHatchback = true
    }
  }
  hatchbackCars()
  {
    return this.cars.filter(hatchback => hatchback.category == 'Car' && hatchback.subCategory == 'Hatchback')
  }
  scooterClick()
  {
    this.isSport = false
    this.isStandard = false
    this.isCruiser = false
    this.isAllBikes = false
    if(this.isScooter == true)
    {
      this.isScooter = false
      this.isAllBikes = true
    }
    else
    {
      this.isScooter = true
    }
  }
  scooterBikes()
  {
    return this.bikes.filter(scooter => scooter.category == 'Bike' && scooter.subCategory == 'Scooter')
  }
  sportClick()
  {
    this.isStandard = false
    this.isCruiser = false
    this.isScooter = false
    this.isAllBikes = false
    if(this.isSport == true)
    {
      this.isSport = false
      this.isAllBikes = true
    }
    else
    {
      this.isSport = true
    }
  }
  sportBikes()
  {
    return this.bikes.filter(sport => sport.category == 'Bike' && sport.subCategory == 'Sport')
  }
  standardClick()
  {
    this.isCruiser = false
    this.isScooter = false
    this.isSport = false
    this.isAllBikes = false
    if(this.isStandard == true)
    {
      this.isStandard = false
      this.isAllBikes = true
    }
    else
    {
      this.isStandard = true
    }
  }
  standardBikes()
  {
    return this.bikes.filter(standard => standard.category == 'Bike' && standard.subCategory == 'Standard')
  }
  cruiserClick()
  {
    this.isScooter = false
    this.isSport = false
    this.isStandard = false
    this.isAllBikes = false
    if(this.isCruiser == true)
    {
      this.isCruiser = false
      this.isAllBikes = true
    }
    else
    {
      this.isCruiser = true
    }
  }
  cruiserBikes()
  {
    return this.bikes.filter(cruiser => cruiser.category == 'Bike' && cruiser.subCategory == 'Cruiser')
  }
  reserveVehicle(id:number)
  {
    this.router.navigateByUrl("reserve/"+id)
  }
  editVehicle(id:number)
  {
    this.router.navigateByUrl("edit/"+id)
  }
  onAdd()
  {
    console.log(this.addVehicleForm.value)
    this.vehicleService.addVehicle(this.addVehicleForm).subscribe(
      data => {
        if(data['message'] == "Vehicle Details Successfully added")
        {
          this.isAdded = true
        }
      }
    )
    this.vehicleService.getCars().subscribe(
      data => {
        this.cars = data
        console.log(this.cars)
      }
    )
    this.vehicleService.getBikes().subscribe(
      data => {
        this.bikes = data
        console.log(this.bikes)
      }
    )
  }
  onAddMore()
  {
    this.isAdded = false
    this.addVehicleForm = this.formBuilder.group({
      vehicleNumber: ['',Validators.required],
      vehicleName: ['',Validators.required],
      category: ['',Validators.required],
      branch: ['',Validators.required],
      subCategory: ['',Validators.required],
      insuranceExpiryDate: ['',Validators.required],
      lastServiceDate: ['',Validators.required],
      serviceDueDate: ['',Validators.required],
      fee: ['',Validators.required]
    })
  }
}