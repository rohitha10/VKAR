import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { VehicleService } from 'src/app/service/vehicle.service';
import { ActivatedRoute, Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import { UserService } from 'src/app/service/user.service';
import { Vehicle } from 'src/app/models/vehicle';
import { Payment } from 'src/app/models/payment';
import { Reservation } from 'src/app/models/reservation';

@Component({
  selector: 'app-reserve',
  templateUrl: './reserve.component.html',
  styleUrls: ['./reserve.component.css']
})
export class ReserveComponent implements OnInit {

  vehicleDetails: Vehicle
  vehicleId: number
  isPayment: boolean
  isCard: boolean
  isNetBanking: boolean
  isUPI: boolean
  isPaytm: boolean
  isNotValid: boolean
  isCannotBook: boolean
  showModal: boolean
  reservationDetails: Reservation
  paymentDetails: Payment
  message: string
  dateStart = new Date()
  dateEnd = new Date();
  promoCodeSuccess: boolean
  promoCodeFailure: boolean
  promoCodeMessage: string
  discountPercentage: number
  discount: number
  minStartDate = this.datepipe.transform(this.dateStart, 'yyyy-MM-dd')
  minEndDate
  reserveVehicleForm = this.formBuilder.group({
    vehicleName: [''],
    userName: [''],
    vehicleId: [''],
    memberId: [''],
    startDate: ['',Validators.required],
    endDate: ['',Validators.required],
    fee: ['', Validators.required],
    numberOfDays: [0],
    driverNeeded: [''],
    licenseNumber: [''],
    refund: [''],
    status: [false],
    comments: [''],
    paymentMethod: [''],
    feePaid: [''],
    transactionStatus: [''],
    promoCode: ['']
  })
  reserveCardPayment = this.formBuilder.group({
    cardNumber: [''],
    cvv: [''],
    expiryDate: ['']
  })
  reserveNbPayment = this.formBuilder.group({
    bankName: ['']
  })
  reserveUPIPayment = this.formBuilder.group({
    upiId: ['']
  })
  reservePaytmPayment = this.formBuilder.group({
    mobileNumber: ['']
  })

  constructor(private formBuilder: FormBuilder, private vehicleService: VehicleService, private activatedRoute: ActivatedRoute, private datepipe: DatePipe, private userService: UserService, private router: Router) { }

  ngOnInit() {
    this.showModal = false
    this.isCannotBook = false
    this.isPayment = false
    this.isNotValid = false
    this.dateEnd.setDate(this.dateEnd.getDate() + 1)
    this.minEndDate = this.datepipe.transform(this.dateEnd, 'yyyy-MM-dd')
    this.vehicleId = this.activatedRoute.snapshot.params['id'] as number
    this.vehicleService.getVehicle(this.vehicleId).subscribe(
      data => {
        console.log(data)
        this.vehicleDetails = data
        this.reserveVehicleForm = this.formBuilder.group({
          vehicleName: [this.vehicleDetails.vehicleName],
          userName: [this.userService.loggedInUser.firstName],
          vehicleId: [this.vehicleDetails.id],
          memberId: [this.userService.loggedInUser.id],
          startDate: ['',Validators.required],
          endDate: ['',Validators.required],
          fee: [this.vehicleDetails.fee],
          numberOfDays: [0],
          driverNeeded: [false],
          licenseNumber: [''],
          refund: [''],
          status: [false],
          comments: [''],
          paymentMethod: [''],
          transactionStatus: [''],
          promoCode: ['']
        })
      }
    )
  }

  show()
  {
    this.showModal = true
  }
  hide()
  {
    this.showModal = false;
  }
  calculateStartDays()
  {
    this.dateEnd.setDate(this.reserveVehicleForm.get('startDate').value.getDate() + 1)
    this.minEndDate = this.datepipe.transform(this.dateEnd,'yyyy-MM-dd')
    console.log(this.minEndDate)
    let oneDay = 1000*60*60*24
    let startDate = new Date(this.reserveVehicleForm.get('startDate').value)
    let endDate = new Date(this.reserveVehicleForm.get('endDate').value)
    let days = Math.round(Math.abs((endDate.getTime() - startDate.getTime())/(24*60*60*1000)))
    // let days = difference / (24*60*60*1000);
    console.log(days as number)
    this.reserveVehicleForm.patchValue({fee: this.vehicleDetails.fee*days})
    this.reserveVehicleForm.patchValue({numberOfDays: days})
  }
  calculateDays(vehicleFee:any)
  {
    let oneDay = 1000*60*60*24
    let startDate = new Date(this.reserveVehicleForm.get('startDate').value)
    let endDate = new Date(this.reserveVehicleForm.get('endDate').value)
    let days = Math.round(Math.abs((endDate.getTime() - startDate.getTime())/(24*60*60*1000)))
    // let days = difference / (24*60*60*1000);
    console.log(days as number)
    this.reserveVehicleForm.patchValue({fee: this.vehicleDetails.fee*days})
    this.reserveVehicleForm.patchValue({numberOfDays: days})
  }

  onReserve()
  {
    this.vehicleService.checkDates(this.vehicleId,this.reserveVehicleForm.get('startDate').value,this.reserveVehicleForm.get('endDate').value).subscribe(
      data => {
        console.log(data)
        if(data['status']=="Proceed")
        {
          this.isPayment = true
        }
        else
        {
          this.isCannotBook = true
        }
      }
    ) 
  }
  onCard(){
    this.isCard = true
    this.isNetBanking = false
    this.isUPI = false
    this.isPaytm = false
  }
  onNetBanking(){
    this.isCard = false
    this.isNetBanking = true
    this.isUPI = false
    this.isPaytm = false
  }
  onUPI(){
    this.isCard = false
    this.isNetBanking = false
    this.isUPI = true
    this.isPaytm = false
  }
  onPaytm(){
    this.isCard = false
    this.isNetBanking = false
    this.isUPI = false
    this.isPaytm = true
  }
  onCardPayment()
  {
    console.log(this.reserveCardPayment.get('expiryDate').value)
    if(this.reserveCardPayment.get('cardNumber').value == "" || this.reserveCardPayment.get('cvv').value == "" || this.reserveCardPayment.get('expiryDate').value == ""){
      this.isNotValid = true
    }
    else
    {
      this.isNotValid = false
    }
    if(this.isNotValid == false)
    {
      console.log("Entered Card Payment Process")
      this.reserveVehicleForm.patchValue({paymentMethod: 'Card'})
      this.reserveVehicleForm.patchValue({transactionStatus: 'Success'})
      this.vehicleService.reserveVehicle(this.reserveVehicleForm).subscribe(
        data => {
          this.message = data['message']
          if(this.message == "Vehicle Booked")
          {
            this.reservationDetails = data['reservation'][0]
            this.paymentDetails = data['payment'][0]
            console.log(data)
            this.show()
          }
          else
          {
            this.paymentDetails = data['payment']
            console.log(data)
            this.show()
          }
        }
      )
    }
  }
  onNbPayment()
  {
    console.log(this.reserveNbPayment.get('bankName').value)
    if(this.reserveNbPayment.get('bankName').value == ""){
      this.isNotValid = true
    }
    else
    {
      this.isNotValid = false
    }
    if(this.isNotValid == false)
    {
      console.log("Entered Card Payment Process")
      this.reserveVehicleForm.patchValue({paymentMethod: 'Net Banking'})
      this.reserveVehicleForm.patchValue({transactionStatus: 'Failure'})
      this.vehicleService.reserveVehicle(this.reserveVehicleForm).subscribe(
        data => {
          this.message = data['message']
          if(this.message == "Vehicle Booked")
          {
            this.reservationDetails = data['reservation'][0]
            this.paymentDetails = data['payment'][0]
            console.log(data)
            this.show()
          }
          else
          {
            this.paymentDetails = data['payment']
            console.log(data)
            this.show()
          }
        }
      )
    }
  }
  onUPIPayment()
  {
    console.log(this.reserveUPIPayment.get('upiId').value)
    if(this.reserveUPIPayment.get('upiId').value == ""){
      this.isNotValid = true
    }
    else
    {
      this.isNotValid = false
    }
    if(this.isNotValid == false)
    {
      console.log("Entered Card Payment Process")
      this.reserveVehicleForm.patchValue({paymentMethod: 'UPI'})
      this.reserveVehicleForm.patchValue({transactionStatus: 'Success'})
      this.vehicleService.reserveVehicle(this.reserveVehicleForm).subscribe(
        data => {
          this.message = data['message']
          if(this.message == "Vehicle Booked")
          {
            this.reservationDetails = data['reservation'][0]
            this.paymentDetails = data['payment'][0]
            console.log(data)
            this.show()
          }
          else
          {
            this.paymentDetails = data['payment']
            console.log(data)
            this.show()
          }
        }
      )
    }
  }
  onPaytmPayment(){
    console.log(this.reservePaytmPayment.get('mobileNumber').value)
    if(this.reservePaytmPayment.get('mobileNumber').value == ""){
      this.isNotValid = true
    }
    else
    {
      this.isNotValid = false
    }
    if(this.isNotValid == false)
    {
      console.log("Entered Card Payment Process")
      this.reserveVehicleForm.patchValue({paymentMethod: 'Paytm'})
      this.reserveVehicleForm.patchValue({transactionStatus: 'Failure'})
      this.vehicleService.reserveVehicle(this.reserveVehicleForm).subscribe(
        data => {
          this.message = data['message']
          if(this.message == "Vehicle Booked")
          {
            this.reservationDetails = data['reservation'][0]
            this.paymentDetails = data['payment'][0]
            console.log(data)
            this.show()
          }
          else
          {
            this.paymentDetails = data['payment']
            console.log(data)
            this.show()
          }
        }
      )
    }
  }
  onClose()
  {
    this.router.navigateByUrl('vehicles')
  }
  onApply()
  {
    this.vehicleService.checkPromoCode(this.reserveVehicleForm.get('promoCode').value).subscribe(
      data => {
        this.promoCodeMessage = data['message']
        if(this.promoCodeMessage == 'Valid')
        {
          this.promoCodeSuccess = true
          this.promoCodeFailure = false
          this.discountPercentage = data['value']
          this.discount = this.vehicleDetails.fee*(this.discountPercentage/100)*this.reserveVehicleForm.get('numberOfDays').value
          this.reserveVehicleForm.patchValue({fee: this.vehicleDetails.fee*((100 - this.discountPercentage)/100)*this.reserveVehicleForm.get('numberOfDays').value})
        }
        else if(this.promoCodeMessage == 'Expired')
        {
          this.promoCodeFailure = true
          this.promoCodeSuccess = false
          this.reserveVehicleForm.patchValue({fee: this.vehicleDetails.fee*this.reserveVehicleForm.get('numberOfDays').value})
        }
        else if(this.promoCodeMessage == 'Not valid')
        {
          this.promoCodeFailure = true
          this.promoCodeSuccess = false
          this.reserveVehicleForm.patchValue({fee: this.vehicleDetails.fee*this.reserveVehicleForm.get('numberOfDays').value})
        }
      }
    )
  }
}
