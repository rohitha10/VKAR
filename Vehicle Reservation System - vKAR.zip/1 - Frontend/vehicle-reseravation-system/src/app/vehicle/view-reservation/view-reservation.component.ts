import { Component, OnInit } from '@angular/core';
import { VehicleService } from 'src/app/service/vehicle.service';
import { Reservation } from 'src/app/models/reservation';
import { Bookings } from 'src/app/models/bookings';
import { DatePipe } from '@angular/common';
import { Router } from '@angular/router';
import * as XLSX from 'xlsx';

@Component({
  selector: 'app-view-reservation',
  templateUrl: './view-reservation.component.html',
  styleUrls: ['./view-reservation.component.css']
})
export class ViewReservationComponent implements OnInit {

  reservations : Bookings[]
  today = new Date()
  isAll: boolean
  isUpcoming: boolean
  isPast: boolean
  isPresent: boolean
  isCancelled: boolean
  fileName= 'vKAR-Report.xlsx';
  constructor(private vehicleService: VehicleService, private datepipe: DatePipe, private router:Router) { }

  ngOnInit() {
    this.isAll = true
    this.vehicleService.getReservations().subscribe(
      data => {
        console.log(data)
        this.reservations = data
        this.reservations = this.reservations.sort()
        console.log(this.reservations)
        console.log(this.datepipe.transform(this.today, 'yyyy-MM-dd'))
        //console.log(this.reservations.filter(reservation => reservation.startDate. > this.today.getDate()));
      }
    )
  }

  upcoming()
  {
    return this.reservations.filter(reservation => reservation.startDate.toString() > this.datepipe.transform(this.today, 'yyyy-MM-dd') && reservation.status == false)
  }

  past()
  {
    return this.reservations.filter(reservation => reservation.endDate.toString() < this.datepipe.transform(this.today, 'yyyy-MM-dd') && reservation.status == false)
  }

  present()
  {
    return this.reservations.filter(reservation => (reservation.endDate.toString() >= this.datepipe.transform(this.today, 'yyyy-MM-dd')) && (reservation.startDate.toString() <= this.datepipe.transform(this.today, 'yyyy-MM-dd')) && reservation.status == false )
  }

  cancelled()
  {
    return this.reservations.filter(reservation => reservation.status == true)
  }

  onAll()
  {
    this.isAll = true
    this.isUpcoming = false
    this.isPast = false
    this.isPresent = false
    this.isCancelled = false
  }
  onUpcoming()
  {
    this.isAll = false
    this.isUpcoming = true
    this.isPast = false
    this.isPresent = false
    this.isCancelled = false
  }
  onPast()
  {
    this.isAll = false
    this.isUpcoming = false
    this.isPast = true
    this.isPresent = false
    this.isCancelled = false
  }
  onPresent()
  {
    this.isAll = false
    this.isUpcoming = false
    this.isPast = false
    this.isPresent = true
    this.isCancelled = false
  }
  onCancelled()
  {
    this.isAll = false
    this.isUpcoming = false
    this.isPast = false
    this.isPresent = false
    this.isCancelled = true
  }

  cancelClicked(transactionId:number)
  {
    this.router.navigateByUrl('cancel/'+transactionId)
  }

  exportReservations(){
    const ws: XLSX.WorkSheet =XLSX.utils.json_to_sheet(this.reservations);
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Reservations');
    XLSX.writeFile(wb, this.fileName);
  }
}