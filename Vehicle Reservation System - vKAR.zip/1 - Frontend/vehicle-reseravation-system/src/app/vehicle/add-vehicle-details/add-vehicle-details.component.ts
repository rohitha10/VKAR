import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-add-vehicle-details',
  templateUrl: './add-vehicle-details.component.html',
  styleUrls: ['./add-vehicle-details.component.css']
})
export class AddVehicleDetailsComponent implements OnInit {

  constructor(private formBuilder:FormBuilder) { }

  AdminAddVehicle = this.formBuilder.group({
    vehicleno:['',[Validators.required, Validators.maxLength(10)]],
    branch:['',[Validators.required, Validators.maxLength(5)]],
    vehicleType:['',Validators.required, Validators.maxLength(15)],
    insuranceExpDate:['',Validators.required, Validators.maxLength(10)],
    lastServicedDate:['',Validators.required, Validators.maxLength(0)],
    serviceDueDate:['',[Validators.required, Validators.maxLength(10)]],
    
  })
  get formControls() { return this.AdminAddVehicle.controls; }


  ngOnInit() {
  }

}