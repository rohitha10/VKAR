import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { VehicleService } from 'src/app/service/vehicle.service';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-cancel',
  templateUrl: './cancel.component.html',
  styleUrls: ['./cancel.component.css']
})
export class CancelComponent implements OnInit {

  reservationDetails
  transactionId
  vehicleDetails
  isCancelled: boolean = false
  message
  cancellationForm = this.formBuilder.group({
    comment:['',Validators.required]
  })
  constructor(private activatedRoute: ActivatedRoute, private vehicleService: VehicleService, private formBuilder:FormBuilder, private router: Router) { }

  ngOnInit() {
    this.transactionId = this.activatedRoute.snapshot.params['transactionId'] as number
    this.vehicleService.getReservationDetails(this.transactionId).subscribe(
      data => {
        this.reservationDetails = data
        this.vehicleService.getVehicle(this.reservationDetails['vehicleId']).subscribe(
          vehicle => {
            this.vehicleDetails = vehicle
            console.log(this.vehicleDetails)
          }
        )
      }
    )
  }

  onProceed()
  {
    this.vehicleService.cancelReservation(this.transactionId,this.cancellationForm.get('comment').value).subscribe(
      data => {
        if(data['message'] == 'Cancelled')
        {
          this.isCancelled = true
        }
      }
    )
  }

  onClose()
  {
    this.router.navigateByUrl('reservations')
  }
}