import { Component, OnInit } from '@angular/core';
import { VehicleService } from 'src/app/service/vehicle.service';
import { DatePipe } from '@angular/common';
import { Bookings } from 'src/app/models/bookings';
import * as XLSX from 'xlsx';
import { Router } from '@angular/router';
import { User } from 'src/app/models/user';
import { UserService } from 'src/app/service/user.service';
import { Vehicle } from 'src/app/models/vehicle';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  reservations : Bookings[]
  users : User[]
  today = new Date()
  cars : Vehicle[]
  bikes : Vehicle[]
  fileName = 'vKAR-Report.xlsx';
  dailyReportFileName = 'vKAR-Report-Daily.xlsx';

  constructor(private vehicleService: VehicleService, private datepipe: DatePipe, private router: Router, private userService: UserService) { }

  ngOnInit() {
    this.vehicleService.getAllReservations().subscribe(
      data => {
        console.log(data)
        this.reservations = data
        console.log(this.reservations)
      }
    )
    this.userService.getAllUsers().subscribe(
      data => {
        console.log(data)
        this.users = data
        console.log(this.users)
      }
    )
    this.vehicleService.getBikes().subscribe(
      data => {
        console.log(data)
        this.bikes = data
        console.log(this.bikes)
      }
    )
    this.vehicleService.getCars().subscribe(
      data => {
        console.log(data)
        this.cars = data
        console.log(this.cars)
      }
    )
  }
  upcoming()
  {
    return this.reservations.filter(reservation => reservation.startDate.toString() > this.datepipe.transform(this.today, 'yyyy-MM-dd') && reservation.status == false)
  }

  past()
  {
    return this.reservations.filter(reservation => reservation.endDate.toString() < this.datepipe.transform(this.today, 'yyyy-MM-dd') && reservation.status == false)
  }

  present()
  {
    return this.reservations.filter(reservation => (reservation.endDate.toString() >= this.datepipe.transform(this.today, 'yyyy-MM-dd')) && (reservation.startDate.toString() <= this.datepipe.transform(this.today, 'yyyy-MM-dd')) && reservation.status == false )
  }

  cancelled()
  {
    return this.reservations.filter(reservation => reservation.status == true)
  }
  exportReservations(){
    const ws: XLSX.WorkSheet =XLSX.utils.json_to_sheet(this.reservations);
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Reservations');
    XLSX.writeFile(wb, this.datepipe.transform(this.today, 'yyyy-MM-dd')+" vKAR Total Report.xlsx");
  }
  exportDailyReport(){
    const ws: XLSX.WorkSheet =XLSX.utils.json_to_sheet(this.present());
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Reservations');
    XLSX.writeFile(wb, this.datepipe.transform(this.today, 'yyyy-MM-dd')+" vKAR Daily Report.xlsx");
  }
  onNewReg(){
    this.router.navigateByUrl("registrationRequests");
  }
  admins()
  {
    return this.users.filter(user => user.role == 'admin' && user.status == true)
  }
  customers()
  {
    return this.users.filter(user => user.role == 'user' && user.status == true)
  }
  newReg()
  {
    return this.users.filter(user => user.status == false && user.reject == false)
  }
}
