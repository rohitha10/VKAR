export class Vehicle {
    id: number
    vehicleNumber: string
    vehicleName: string
    branch: string
    category: string
    subCategory: string
    insuranceExpiryDate: Date
    lastServiceDate: Date
    serviceDueDate: Date
    fee: number
}
