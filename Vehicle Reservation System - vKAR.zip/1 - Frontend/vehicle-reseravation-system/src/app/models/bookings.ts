export class Bookings {
    vehicleId?: number
    id?: number
    vehicleName?: string
    vehicleNumber?: string
    startDate?: Date
    endDate?: Date
    fee?: number
    refund?: number
    status?: boolean
    licenseNumber?: string
    driverNeeded?: boolean
    feepaid?: number
    paymentMethod?: string
    transactionId?: number
}
