export class Reservation {
    transactionId?: number
    memberId?: number
    vehicleId?: number
    startDate?: Date
    endDate?: Date
    driverNeeded?: boolean
    licenseNumber?: string
    status?: boolean
    fee?: number
}
