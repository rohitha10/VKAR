import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/service/user.service';
import { VehicleService } from 'src/app/service/vehicle.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  lastReservation
  vehicle

  constructor(private userService: UserService, private vehicleService: VehicleService) { }

  ngOnInit() {
    this.vehicleService.getLastReservation(this.getUser().id).subscribe(
      data => {
        this.lastReservation = data
        this.vehicleService.getVehicle(this.lastReservation.vehicleId).subscribe(
          data => {
            this.vehicle = data
          }
        )
      }
    )
  }

  getUser()
  {
    return this.userService.loggedInUser
  }
  isAdmin()
  {
    return this.isAdmin
  }
}
