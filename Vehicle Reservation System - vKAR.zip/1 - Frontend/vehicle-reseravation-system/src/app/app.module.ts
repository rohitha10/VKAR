import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ClipboardModule } from 'ngx-clipboard';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './site/header/header.component';
import { LoginComponent } from './site/login/login.component';
import { VehicleInfoComponent } from './vehicle/vehicle-info/vehicle-info.component';
import { SignupComponent } from './site/signup/signup.component';
import { ReactiveFormsModule } from '@angular/forms';
import { VehicleListComponent } from './vehicle/vehicle-list/vehicle-list.component';
import { AddVehicleDetailsComponent } from './vehicle/add-vehicle-details/add-vehicle-details.component';
import { HttpClientModule } from '@angular/common/http';
import { RegisteredUsersComponent } from './user/registered-users/registered-users.component'
import { AsyncPipe, DatePipe } from '@angular/common';
import { SubmittedForApprovalComponent } from './site/submitted-for-approval/submitted-for-approval.component';
import { FooterComponent } from './site/footer/footer.component';
import { FooterTwoComponent } from './site/footer-two/footer-two.component';
import { ReserveComponent } from './vehicle/reserve/reserve.component';
import { VehicleEditComponent } from './vehicle/vehicle-edit/vehicle-edit.component';
import { RemovedFromVehiclesComponent } from './site/removed-from-vehicles/removed-from-vehicles.component';
import { UpdatedVehiclesComponent } from './site/updated-vehicles/updated-vehicles.component';
import { DashboardComponent } from './admin/dashboard/dashboard.component';
import { ViewReservationComponent } from './vehicle/view-reservation/view-reservation.component';
import { CancelComponent } from './vehicle/cancel/cancel.component';
import { ProfileComponent } from './user/profile/profile.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    LoginComponent,
    VehicleInfoComponent,
    SignupComponent,
    VehicleListComponent,
    AddVehicleDetailsComponent,
    RegisteredUsersComponent,
    SubmittedForApprovalComponent,
    FooterComponent,
    FooterTwoComponent,
    ReserveComponent,
    VehicleEditComponent,
    RemovedFromVehiclesComponent,
    UpdatedVehiclesComponent,
    DashboardComponent,
    ViewReservationComponent,
    CancelComponent,
    ProfileComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    ClipboardModule,
  ],
  providers: [AsyncPipe, DatePipe],
  bootstrap: [AppComponent]
})
export class AppModule { }
