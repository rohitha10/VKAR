import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-submitted-for-approval',
  templateUrl: './submitted-for-approval.component.html',
  styleUrls: ['./submitted-for-approval.component.css']
})
export class SubmittedForApprovalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
