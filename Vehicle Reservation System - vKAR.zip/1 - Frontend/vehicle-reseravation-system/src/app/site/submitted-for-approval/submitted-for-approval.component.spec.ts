import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SubmittedForApprovalComponent } from './submitted-for-approval.component';

describe('SubmittedForApprovalComponent', () => {
  let component: SubmittedForApprovalComponent;
  let fixture: ComponentFixture<SubmittedForApprovalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SubmittedForApprovalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SubmittedForApprovalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
