import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from 'src/app/service/user.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  showModal: boolean;
  isAdmin: boolean = false;
  isEmailExist: boolean
  private passwordNotSame:boolean
  private empIdNotProvided:boolean 
  constructor(private formBuilder:FormBuilder, private userService:UserService, private router:Router) { }

  adminClick()
  {
    this.isAdmin = true;
    console.log(this.isAdmin);
    this.show()
  }
  userClick()
  {
    this.isAdmin = false;
    console.log(this.isAdmin);
    this.show()
  }
  show()
  {
    this.showModal = true; // Show-Hide Modal Check
  }
  //Bootstrap Modal Close event
  hide()
  {
    this.showModal = false;
  }

  userCreationForm = this.formBuilder.group({
    adminId:['',[Validators.maxLength(6),Validators.pattern('[0-9]*$')]],
    firstName:['',[Validators.required, Validators.maxLength(20)]],
    lastName:['',Validators.required],
    age:['',Validators.required],
    gender:['',Validators.required],
    contactNumber:['',[Validators.required, Validators.maxLength(10), Validators.pattern('[0-9]*$')]],
    branch:['',[Validators.required, Validators.maxLength(20)]],
    password:['',[Validators.required,Validators.minLength(8)]],
    emailId:['',[Validators.required, Validators.email]],
    status:[false],
    reject:[false],
    role:['']
  })

  get formControls() { return this.userCreationForm.controls; }

  onSubmit() {
    if(this.isAdmin)
    {
      if(this.userCreationForm.value['adminId']=='')
      {
        this.empIdNotProvided = true;
      }
      else
      {
        this.userCreationForm.patchValue({role:'admin'})
        console.log(this.userCreationForm.value)
        this.userService.register(this.userCreationForm).subscribe(
          data => {
            console.log(data)
            if(data['message'] == "Registered")
            {
              this.router.navigateByUrl("submitted")
            }
          }
        )
      }
    }
    else if(this.isAdmin == false)
    {
      this.userCreationForm.patchValue({role:'user'})
      console.log(this.userCreationForm.value)
      this.userService.register(this.userCreationForm).subscribe(
        data => {
          console.log(data)
          if(data['message'] == "Registered")
          {
            this.router.navigateByUrl("submitted")
          }
        }
      )
    }

    
    console.log(this.userCreationForm.getRawValue())
    //console.log(this.userService.userList)
    //this.router.navigateByUrl('/login');
  }

  ngOnInit() {
  }

  onEmailChange(emailId:string)
  {
    console.log(emailId)
    this.userService.checkEmail(emailId).subscribe(
      data => {
        console.log(data)
        if(data['status'] == "No such email")
        {
          this.isEmailExist = false
        }
        else if(data['status'] == "Email already exist")
        {
          this.isEmailExist = true
        }
      }
    )
  }

  onConfirmPassword(event:any){
    if(event.target.value != this.userCreationForm.value['password'])
    {
      this.passwordNotSame = true;
    }
    else
    {
      this.passwordNotSame = false;
    }
  }
  
  onPassword(event:any,password:string){
    this.passwordNotSame = true;
    if(event.target.value != password)
    {
      this.passwordNotSame = true;
    }
    else
    {
      this.passwordNotSame = false;
    }
  }

}
