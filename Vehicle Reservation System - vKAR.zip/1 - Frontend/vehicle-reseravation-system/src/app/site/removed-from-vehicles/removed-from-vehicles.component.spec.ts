import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RemovedFromVehiclesComponent } from './removed-from-vehicles.component';

describe('RemovedFromVehiclesComponent', () => {
  let component: RemovedFromVehiclesComponent;
  let fixture: ComponentFixture<RemovedFromVehiclesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RemovedFromVehiclesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RemovedFromVehiclesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
