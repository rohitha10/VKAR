import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-removed-from-vehicles',
  templateUrl: './removed-from-vehicles.component.html',
  styleUrls: ['./removed-from-vehicles.component.css']
})
export class RemovedFromVehiclesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
