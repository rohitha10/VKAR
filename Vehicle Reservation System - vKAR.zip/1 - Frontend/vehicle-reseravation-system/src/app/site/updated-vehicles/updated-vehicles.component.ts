import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-updated-vehicles',
  templateUrl: './updated-vehicles.component.html',
  styleUrls: ['./updated-vehicles.component.css']
})
export class UpdatedVehiclesComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }

  viewClicked()
  {
    this.router.navigateByUrl("dashboard")
  }
}
