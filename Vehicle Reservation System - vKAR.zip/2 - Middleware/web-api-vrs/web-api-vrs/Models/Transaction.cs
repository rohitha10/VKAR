﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace web_api_vrs.Models
{
    public class Transaction
    {
        public string PaymentMethod { get; set; }
        public long Fee { get; set; }
        public string TransactionStatus { get; set; }
        public int VehicleId { get; set; }
        public int MemberId { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public bool? DriverNeeded { get; set; }
        public string LicenseNumber { get; set; }
        public long? Refund { get; set; }
        public bool Status { get; set; }
        public string Comments { get; set; }
    }
}
