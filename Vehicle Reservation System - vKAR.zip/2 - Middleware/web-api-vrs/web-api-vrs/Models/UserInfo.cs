﻿using System;
using System.Collections.Generic;

namespace web_api_vrs.Models
{
    public partial class UserInfo
    {
        public UserInfo()
        {
            Payment = new HashSet<Payment>();
            Reservation = new HashSet<Reservation>();
        }

        public int Id { get; set; }
        public long? AdminId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Age { get; set; }
        public string Gender { get; set; }
        public long ContactNumber { get; set; }
        public string EmailId { get; set; }
        public string Password { get; set; }
        public string Branch { get; set; }
        public bool Status { get; set; }
        public string Role { get; set; }
        public bool Reject { get; set; }
        public string Comments { get; set; }

        public virtual ICollection<Payment> Payment { get; set; }
        public virtual ICollection<Reservation> Reservation { get; set; }
    }
}
