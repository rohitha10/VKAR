﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace web_api_vrs.Models
{
    public partial class vKARContext : DbContext
    {
        public vKARContext()
        {
        }

        public vKARContext(DbContextOptions<vKARContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Payment> Payment { get; set; }
        public virtual DbSet<PromoCode> PromoCode { get; set; }
        public virtual DbSet<Reservation> Reservation { get; set; }
        public virtual DbSet<UserInfo> UserInfo { get; set; }
        public virtual DbSet<VehicleInfo> VehicleInfo { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("server=PCIN480258;database=vKAR;trusted_connection=yes");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.3-servicing-35854");

            modelBuilder.Entity<Payment>(entity =>
            {
                entity.ToTable("payment");

                entity.HasIndex(e => e.TransactionId)
                    .HasName("UQ__payment__85C600AEACA15052")
                    .IsUnique();

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.FeePaid).HasColumnName("fee_paid");

                entity.Property(e => e.MemberId).HasColumnName("member_id");

                entity.Property(e => e.PaymentMethod)
                    .HasColumnName("payment_method")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.TransactionId).HasColumnName("transaction_id");

                entity.Property(e => e.TransactionStatus)
                    .IsRequired()
                    .HasColumnName("transaction_status")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.HasOne(d => d.Member)
                    .WithMany(p => p.Payment)
                    .HasForeignKey(d => d.MemberId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("member_id_fk");
            });

            modelBuilder.Entity<PromoCode>(entity =>
            {
                entity.ToTable("promo_code");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Code)
                    .IsRequired()
                    .HasColumnName("code")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Percentage).HasColumnName("percentage");

                entity.Property(e => e.Status).HasColumnName("status");
            });

            modelBuilder.Entity<Reservation>(entity =>
            {
                entity.ToTable("reservation");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Comments)
                    .HasColumnName("comments")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.DriverNeeded).HasColumnName("driver_needed");

                entity.Property(e => e.EndDate)
                    .HasColumnName("end_date")
                    .HasColumnType("date");

                entity.Property(e => e.Fee).HasColumnName("fee");

                entity.Property(e => e.LicenseNumber)
                    .HasColumnName("license_number")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.MemberId).HasColumnName("member_id");

                entity.Property(e => e.Refund).HasColumnName("refund");

                entity.Property(e => e.StartDate)
                    .HasColumnName("start_date")
                    .HasColumnType("date");

                entity.Property(e => e.Status).HasColumnName("status");

                entity.Property(e => e.TransactionId).HasColumnName("transaction_id");

                entity.Property(e => e.VehicleId).HasColumnName("vehicle_id");

                entity.HasOne(d => d.Member)
                    .WithMany(p => p.Reservation)
                    .HasForeignKey(d => d.MemberId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("member_fk");

                entity.HasOne(d => d.Transaction)
                    .WithMany(p => p.Reservation)
                    .HasPrincipalKey(p => p.TransactionId)
                    .HasForeignKey(d => d.TransactionId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("transaction_id_fk");

                entity.HasOne(d => d.Vehicle)
                    .WithMany(p => p.Reservation)
                    .HasForeignKey(d => d.VehicleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("vehicle_id_fk");
            });

            modelBuilder.Entity<UserInfo>(entity =>
            {
                entity.ToTable("user_info");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.AdminId).HasColumnName("admin_id");

                entity.Property(e => e.Age).HasColumnName("age");

                entity.Property(e => e.Branch)
                    .IsRequired()
                    .HasColumnName("branch")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Comments)
                    .HasColumnName("comments")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ContactNumber).HasColumnName("contact_number");

                entity.Property(e => e.EmailId)
                    .HasColumnName("email_id")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.FirstName)
                    .IsRequired()
                    .HasColumnName("first_name")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Gender)
                    .IsRequired()
                    .HasColumnName("gender")
                    .HasMaxLength(6)
                    .IsUnicode(false);

                entity.Property(e => e.LastName)
                    .IsRequired()
                    .HasColumnName("last_name")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasColumnName("password")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Reject).HasColumnName("reject");

                entity.Property(e => e.Role)
                    .IsRequired()
                    .HasColumnName("role")
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.Status).HasColumnName("status");
            });

            modelBuilder.Entity<VehicleInfo>(entity =>
            {
                entity.ToTable("vehicle_info");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Branch)
                    .IsRequired()
                    .HasColumnName("branch")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Category)
                    .IsRequired()
                    .HasColumnName("category")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Fee).HasColumnName("fee");

                entity.Property(e => e.InsuranceExpiryDate)
                    .HasColumnName("insurance_expiry_date")
                    .HasColumnType("date");

                entity.Property(e => e.LastServiceDate)
                    .HasColumnName("last_service_date")
                    .HasColumnType("date");

                entity.Property(e => e.ServiceDueDate)
                    .HasColumnName("service_due_date")
                    .HasColumnType("date");

                entity.Property(e => e.SubCategory)
                    .IsRequired()
                    .HasColumnName("sub_category")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.VehicleName)
                    .IsRequired()
                    .HasColumnName("vehicle_name")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.VehicleNumber)
                    .IsRequired()
                    .HasColumnName("vehicle_number")
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });
        }
    }
}
