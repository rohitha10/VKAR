﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace web_api_vrs.Models
{
    
       
 public class Credentials
        {
            public string EmailId { get; set; }
            public string Password { get; set; }
        }


    }

