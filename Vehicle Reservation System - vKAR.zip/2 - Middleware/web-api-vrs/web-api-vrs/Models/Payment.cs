﻿using System;
using System.Collections.Generic;

namespace web_api_vrs.Models
{
    public partial class Payment
    {
        public Payment()
        {
            Reservation = new HashSet<Reservation>();
        }

        public int Id { get; set; }
        public int MemberId { get; set; }
        public long TransactionId { get; set; }
        public string PaymentMethod { get; set; }
        public long? FeePaid { get; set; }
        public string TransactionStatus { get; set; }

        public virtual UserInfo Member { get; set; }
        public virtual ICollection<Reservation> Reservation { get; set; }
    }
}
