﻿using System;
using System.Collections.Generic;

namespace web_api_vrs.Models
{
    public partial class PromoCode
    {
        public int Id { get; set; }
        public string Code { get; set; }
        public int Percentage { get; set; }
        public bool Status { get; set; }
    }
}
