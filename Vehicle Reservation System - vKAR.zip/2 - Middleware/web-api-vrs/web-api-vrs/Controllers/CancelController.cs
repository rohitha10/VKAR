﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using web_api_vrs.Models;

namespace web_api_vrs.Controllers
{
    [EnableCors("VRSPolicy")]
    [Route("api/[controller]")]
    [ApiController]
    public class CancelController : ControllerBase
    {
        vKARContext vKAR = new vKARContext();
        [Route("cancelBooking/{transactionId}/{comment}")]
        [HttpPut("{transactionId}/{comment}")]
        public IActionResult CancelReservation(long transactionId, string comment)
        {
            Reservation cancel = vKAR.Reservation.Where(c => c.TransactionId == transactionId && c.Status == false).FirstOrDefault();
            if (cancel != null)
            {
                DateTime now = DateTime.Now;
                TimeSpan timespan = cancel.StartDate.Subtract(now);
                if (timespan.Days + 1 >= 2)
                {
                    cancel.Refund = cancel.Fee - Convert.ToInt32(cancel.Fee * 0.1);
                    cancel.Status = true;
                    cancel.Comments = comment;
                }
                else if (timespan.Days + 1 == 1)
                {
                    cancel.Refund = cancel.Fee - Convert.ToInt32(cancel.Fee * 0.2);
                    cancel.Status = true;
                    cancel.Comments = comment;
                }
                else if (timespan.Days + 1 == 0)
                {
                    cancel.Refund = cancel.Fee - Convert.ToInt32(cancel.Fee * 0.3);
                    cancel.Status = true;
                    cancel.Comments = comment;
                }
                else
                {
                    return Ok(new { message = "Cannot cancel" });
                }
                vKAR.SaveChanges();
                return Ok(new { message = "Cancelled" });
            }
            return Ok(new { message = "No such data" });
        }
    }
}