﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using web_api_vrs.Models;

namespace web_api_vrs.Controllers
{
    [EnableCors("VRSPolicy")]
    [Route("api/[controller]")]
    [ApiController]
    public class ReservationController : ControllerBase
    {

        vKARContext vKAR = new vKARContext();
        [Route("getReservations")]
        // view all reservation for admin
        [HttpGet]
        public IActionResult GetReservationDetails()
        {
            var reserve = from res in vKAR.Reservation.Where(r => r.VehicleId == r.Vehicle.Id && r.MemberId == r.Member.Id)
                          select new
                          {
                              res.Member.Id,
                              res.Member.FirstName,
                              res.Member.LastName,
                              res.Member.Gender,
                              res.Member.ContactNumber,
                              res.Member.EmailId,
                              res.LicenseNumber,
                              res.Vehicle.VehicleName,
                              res.Vehicle.VehicleNumber,
                              res.StartDate,
                              res.EndDate,
                              res.Fee,
                              res.Refund,
                              res.Status,
                              res.DriverNeeded,
                              res.TransactionId,
                              res.Transaction.PaymentMethod
                          };


            return Ok(reserve);
        }

        [Route("getReservation/{id}")]
        [HttpGet("{id}")]
        public IActionResult GetReservation(long id)
        {
            return Ok(vKAR.Reservation.Where(r => r.TransactionId == id).FirstOrDefault());
        }
        ///to get the reservation details for a customer
        [Route("getReservationMember/{id}")]
        [HttpGet("{id}")]
        public IActionResult GetReservationDetailsForUser(int id)
        {
            var reserve = from res in vKAR.Reservation.Where(r => r.MemberId == id)
                          select new
                          {
                              res.VehicleId,
                              res.Id,
                              res.Vehicle.VehicleName,
                              res.Vehicle.VehicleNumber,
                              res.StartDate,
                              res.EndDate,
                              res.Fee,
                              res.Refund,
                              res.Status,
                              res.LicenseNumber,
                              res.DriverNeeded,
                              res.Transaction.FeePaid,
                              res.TransactionId,
                              res.Transaction.PaymentMethod
                          };


            return Ok(reserve);
        }

        [Route("checkDates/{vehicleId}/{startDate}/{endDate}")]
        [HttpGet("{vehicleId}/{startDate}/{endDate}")]
        public IActionResult BeforeProceed(long vehicleId, DateTime startDate, DateTime endDate)
        {
            var vehicle = vKAR.Reservation.Where(v => v.VehicleId == vehicleId && v.Status == false);
            if (vehicle.Count() > 0)
            {
                var dateStart = vehicle.Min(v => v.StartDate);
                var dateEnd = vehicle.Max(v => v.EndDate);

                if (dateStart > endDate || dateEnd < startDate)
                    return Ok(new { status = "Proceed" });
                else
                    return Ok(new { status = "Don't Proceed" });
            }
            else
            {
                return Ok(new { status = "Proceed" });
            }
        }


        //reserving the vehicle
        [Route("reserveVehicle")]
        [HttpPost]
        public IActionResult ReserveVehicle([FromBody] Transaction transaction)
        {
            Payment payment = new Payment();
            payment.TransactionId = vKAR.Payment.Max(trans => trans.TransactionId) + 10;
            payment.MemberId = transaction.MemberId;
            payment.PaymentMethod = transaction.PaymentMethod;
            payment.FeePaid = transaction.Fee;
            payment.TransactionStatus = transaction.TransactionStatus;
            vKAR.Payment.Add(payment);
            vKAR.SaveChanges();

            if (transaction.TransactionStatus == "Success")
            {
                VehicleInfo vehicle = vKAR.VehicleInfo.Where(v => v.Id == transaction.VehicleId).FirstOrDefault();

                Reservation reserve = new Reservation();

                reserve.VehicleId = vehicle.Id;
                reserve.MemberId = transaction.MemberId;
                reserve.StartDate = transaction.StartDate;
                reserve.EndDate = transaction.EndDate;
                reserve.LicenseNumber = transaction.LicenseNumber;

                TimeSpan timespan = transaction.EndDate.Subtract(transaction.StartDate);
                reserve.Fee = transaction.Fee;

                reserve.DriverNeeded = transaction.DriverNeeded;
                reserve.Status = false;
                reserve.TransactionId = payment.TransactionId;
                vKAR.Reservation.Add(reserve);
                vKAR.SaveChanges();
                return Ok(new
                {
                    message = "Vehicle Booked",
                    Reservation = from i in vKAR.Reservation.Where(pay => pay.TransactionId == payment.TransactionId)
                                  select new
                                  {
                                      i.TransactionId,
                                      i.MemberId,
                                      i.VehicleId,
                                      i.StartDate,
                                      i.EndDate,
                                      i.DriverNeeded,
                                      i.LicenseNumber,
                                      i.Status,
                                      i.Fee
                                  },
                    Payment = from i in vKAR.Payment.Where(pay => pay.TransactionId == payment.TransactionId)
                              select new
                              {
                                  i.TransactionId,
                                  i.MemberId,
                                  i.PaymentMethod,
                                  i.FeePaid,
                                  i.TransactionStatus
                              }
                });

            }
            else
            {
                return Ok(new
                {
                    message = "Vehicle Booking Failed",
                    Payment = payment
                });

            }
        }


        //cancelling the reservation by the customer.
        [Route("cancelBooking/{memberId}/{vehicleId}/{date}")]
        [HttpPut("{memberId}/{vehicleId}/{date}")]
        public IActionResult CancelReservation(int memberId, int vehicleId, DateTime date, [FromBody] string comment)
        {
            Reservation cancel = vKAR.Reservation.Where(c => c.MemberId == memberId && c.VehicleId == vehicleId && c.StartDate == date && c.Status == false).FirstOrDefault();
            if (cancel != null)
            {
                DateTime now = DateTime.Now;
                TimeSpan timespan = cancel.StartDate.Subtract(now);
                if (timespan.Days + 1 >= 2)
                {
                    cancel.Refund = cancel.Fee - Convert.ToInt32(cancel.Fee * 0.1);
                    cancel.Status = true;
                    cancel.Comments = comment;
                }
                else if (timespan.Days + 1 == 1)
                {
                    cancel.Refund = cancel.Fee - Convert.ToInt32(cancel.Fee * 0.2);
                    cancel.Status = true;
                    cancel.Comments = comment;
                }
                else if (timespan.Days + 1 == 0)
                {
                    cancel.Refund = cancel.Fee - Convert.ToInt32(cancel.Fee * 0.3);
                    cancel.Status = true;
                    cancel.Comments = comment;
                }
                else
                {
                    return Ok(new { message = "Cannot cancel" });
                }
                vKAR.SaveChanges();
                return Ok(new { message = "Cancelled" });
            }
            return Ok(new { message = "No such data" });
        }
        [Route("getCoupon/{promoCode}")]
        [HttpGet("{promoCode}")]
        public IActionResult GetCouponValue(string promoCode)
        {
            var offer = vKAR.PromoCode.Where(promo => promo.Code == promoCode).FirstOrDefault();
            if(offer != null && offer.Status == true)
            {
                return Ok(new { message = "Valid", value = offer.Percentage });
            }
            else if (offer != null && offer.Status == false)
            {
                return Ok(new { message = "Expired" });
            }
            else
            {
                return Ok(new { message = "Not valid" });
            }
        }
        [Route("getLastReservation/{userId}")]
        [HttpGet("{userId}")]
        public IActionResult GetLastReservation(long userId)
        {
            var reservation = vKAR.Reservation.Where(booking => booking.MemberId == userId).LastOrDefault();
            return Ok(reservation);
        }
        //[Route("cancelBooking/{transactionId}/{comment}")]
        //[HttpPut("{transactionId}/{comment}")]
        //public IActionResult CancelReservation(long transactionId, string comment)
        //{
        //    Reservation cancel = vKAR.Reservation.Where(c => c.TransactionId == transactionId && c.Status == false).FirstOrDefault();
        //    if (cancel != null)
        //    {
        //        DateTime now = DateTime.Now;
        //        TimeSpan timespan = cancel.StartDate.Subtract(now);
        //        if (timespan.Days + 1 >= 2)
        //        {
        //            cancel.Refund = cancel.Fee - Convert.ToInt32(cancel.Fee * 0.1);
        //            cancel.Status = true;
        //            cancel.Comments = comment;
        //        }
        //        else if (timespan.Days + 1 == 1)
        //        {
        //            cancel.Refund = cancel.Fee - Convert.ToInt32(cancel.Fee * 0.2);
        //            cancel.Status = true;
        //            cancel.Comments = comment;
        //        }
        //        else if (timespan.Days + 1 == 0)
        //        {
        //            cancel.Refund = cancel.Fee - Convert.ToInt32(cancel.Fee * 0.3);
        //            cancel.Status = true;
        //            cancel.Comments = comment;
        //        }
        //        else
        //        {
        //            return Ok(new { message = "Cannot cancel" });
        //        }
        //        vKAR.SaveChanges();
        //        return Ok(new { message = "Cancelled" });
        //    }
        //    return Ok(new { message = "No such data" });
        //}
    }
}