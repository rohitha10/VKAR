﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using web_api_vrs.Models;

namespace web_api_vrs.Controllers
{
    [EnableCors("VRSPolicy")]
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        vKARContext vKAR = new vKARContext();
        [HttpPost]
        public ActionResult Login([FromBody]Credentials credentials)
        {
            var user = vKAR.UserInfo.Where(loggedUser => (loggedUser.EmailId == credentials.EmailId && loggedUser.Password == credentials.Password)).FirstOrDefault();
            if (user != null)
            {
                if (user.Status == true && user.Reject == false)
                {
                    return Ok(new { Status = "Success", User = user });
                }
                else if(user.Status == false && user.Reject == false)
                {
                    return Ok(new { Status = "Account not approved yet", User = user });
                }
                else
                {
                    return Ok(new { Status = "Your account has been rejected", User = user.Comments });
                }
            }
            else
            {
                return Ok(new { Status = "Invalid Credentials" });
            }
        }
    }
}


