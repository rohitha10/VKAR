﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using web_api_vrs.Models;

namespace web_api_vrs.Controllers
{
    [EnableCors("VRSPolicy")]
    [Route("api/[controller]")]
    [ApiController]
    public class RegistrationController : ControllerBase
    {
        vKARContext vKAR = new vKARContext();

        [HttpPost]
        public IActionResult Register([FromBody] UserInfo usr)
        {
            UserInfo user = new UserInfo();
            user.AdminId = usr.AdminId;
            user.FirstName = usr.FirstName;
            user.LastName = usr.LastName;
            user.Age = usr.Age;
            user.Gender = usr.Gender;
            user.ContactNumber = usr.ContactNumber;
            user.EmailId = usr.EmailId;
            user.Password = usr.Password;
            user.Branch = usr.Branch;
            user.Role = usr.Role;
            user.Status = false;
            user.Reject = false;
            vKAR.UserInfo.Add(user);
            vKAR.SaveChanges();
            return Ok(new { message = "Registered" });
        }
        [Route("checkEmail/{emailId}")]
        [HttpGet("{emailId}")]
        public ActionResult EmailExist(string emailId)
        {
            var user = vKAR.UserInfo.Where(email => email.EmailId == emailId).FirstOrDefault();
            if (user == null)
                return Ok(new { status = "No such email" });
            else
                return Ok(new { status = "Email already exist" });
        }
    }
}





