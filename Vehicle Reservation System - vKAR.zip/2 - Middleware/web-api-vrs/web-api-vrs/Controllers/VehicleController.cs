﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using web_api_vrs.Models;

namespace web_api_vrs.Controllers
{
    [EnableCors("VRSPolicy")]
    [Route("api/[controller]")]
    [ApiController]
    public class VehicleController : ControllerBase
    {
        vKARContext vKAR = new vKARContext();

        [Route("getVehicles")]
        [HttpGet]
        public IActionResult getVehicles()
        {
            return Ok(vKAR.VehicleInfo);

        }
        [Route("getVehicleById/{id}")]
        [HttpGet("{id}")]
        public IActionResult getVehicle(int id)
        {
            return Ok(vKAR.VehicleInfo.Where(vehicle => vehicle.Id == id).FirstOrDefault());

        }
        [Route("getCars")]
        [HttpGet]
        public IActionResult getCars()
        {
            return Ok(vKAR.VehicleInfo.Where(car => car.Category == "Car"));
        }
        [Route("getBikes")]
        [HttpGet]
        public IActionResult getBikes()
        {
            return Ok(vKAR.VehicleInfo.Where(bike => bike.Category == "Bike"));
        }
        [Route("addVehicle")]
        [HttpPost]
        public IActionResult AddVehicle([FromBody] VehicleInfo vehicle)
        {
            VehicleInfo new_vehicle = new VehicleInfo();
            new_vehicle.VehicleNumber = vehicle.VehicleNumber;
            new_vehicle.VehicleName = vehicle.VehicleName;
            new_vehicle.Branch = vehicle.Branch;
            new_vehicle.Category = vehicle.Category;
            new_vehicle.SubCategory = vehicle.SubCategory;
            new_vehicle.InsuranceExpiryDate = vehicle.InsuranceExpiryDate;
            new_vehicle.ServiceDueDate = vehicle.ServiceDueDate;
            new_vehicle.LastServiceDate = vehicle.LastServiceDate;
            new_vehicle.Fee = vehicle.Fee;
            vKAR.VehicleInfo.Add(new_vehicle);
            vKAR.SaveChanges();

            return Ok(new { message = "Vehicle Details Successfully added" });
        }
        [Route("editVehicle/{id}")]
        [HttpPut("{id}")]
        public IActionResult EditVehicle(int id, [FromBody] VehicleInfo vehicle)
        {
            VehicleInfo edit_vehicle = vKAR.VehicleInfo.Where(e => e.Id == id).FirstOrDefault();
            edit_vehicle.VehicleName = vehicle.VehicleName;
            edit_vehicle.Branch = vehicle.Branch;
            edit_vehicle.Category = vehicle.Category;
            edit_vehicle.SubCategory = vehicle.SubCategory;
            edit_vehicle.InsuranceExpiryDate = vehicle.InsuranceExpiryDate;
            edit_vehicle.ServiceDueDate = vehicle.ServiceDueDate;
            edit_vehicle.LastServiceDate = vehicle.LastServiceDate;
            edit_vehicle.Fee = vehicle.Fee;
            vKAR.SaveChanges();
            return Ok(new { message = "Vehicle Details updated Successfully" });
        }
        [Route("deleteVehicle/{id}")]
        [HttpDelete("{id}")]
        public IActionResult DeleteVehicle(int id)
        {
            VehicleInfo del_vehicle = vKAR.VehicleInfo.Where(d => d.Id == id).FirstOrDefault();
            vKAR.VehicleInfo.Remove(del_vehicle);
            vKAR.SaveChanges();
            return Ok(new { message = "vehicle details deleted" });
        }

    }
}